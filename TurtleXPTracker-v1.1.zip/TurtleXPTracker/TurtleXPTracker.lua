--[[------------------------------------------------------------------
  Turtle XP Tracker  (Vanilla / 1.12 / Turtle WoW)
  Author: Tomkai
  Version: 1.1

  Design goal: rock-steady XP/hour that does NOT randomly reset.
  - Cumulative session average = total session XP / total session play time.
  - Session data persists across logout, /reload, and zoning via
    SavedVariablesPerCharacter.
  - Only "active" (logged-in) time is counted.
  - Manual reset via /xp reset.

  v1.1 additions:
  - Vanilla-style gold-bordered frame
  - Purple/blue XP bar with rested overlay (matches default XP bar)
  - Drag-to-resize grip in bottom-right corner
  - Adjustable font size (scroll wheel over frame, or /xp font N)
  - Adjustable overall scale (/xp scale N)
--------------------------------------------------------------------]]--

local ADDON_NAME = "TurtleXPTracker"

-----------------------------------------------------------------------
-- SavedVariables default template
-----------------------------------------------------------------------
local DEFAULTS = {
    sessionXP        = 0,
    sessionSeconds   = 0,
    kills            = 0,
    killXP           = 0,
    lastLevel        = nil,
    lastXP           = nil,
    frame = {
        point    = "CENTER",
        relPoint = "CENTER",
        x        = 0,
        y        = 200,
        width    = 280,
        height   = 150,
        fontSize = 12,
        scale    = 1.0,
        shown    = true,
        locked   = false,
    },
}

local function InitDB()
    if type(TurtleXPTrackerDB) ~= "table" then
        TurtleXPTrackerDB = {}
    end
    for k, v in pairs(DEFAULTS) do
        if TurtleXPTrackerDB[k] == nil then
            if type(v) == "table" then
                TurtleXPTrackerDB[k] = {}
                for k2, v2 in pairs(v) do
                    TurtleXPTrackerDB[k][k2] = v2
                end
            else
                TurtleXPTrackerDB[k] = v
            end
        end
    end
    for k, v in pairs(DEFAULTS.frame) do
        if TurtleXPTrackerDB.frame[k] == nil then
            TurtleXPTrackerDB.frame[k] = v
        end
    end
end

-----------------------------------------------------------------------
-- Helpers
-----------------------------------------------------------------------
local function fmt_int(n)
    if not n then return "0" end
    n = math.floor(n + 0.5)
    local s = tostring(n)
    local out, count = "", 0
    for i = string.len(s), 1, -1 do
        out = string.sub(s, i, i) .. out
        count = count + 1
        if count == 3 and i > 1 then
            out = "," .. out
            count = 0
        end
    end
    return out
end

local function fmt_time(seconds)
    if not seconds or seconds <= 0 then return "--:--" end
    seconds = math.floor(seconds + 0.5)
    local h = math.floor(seconds / 3600)
    local m = math.floor(math.mod(seconds, 3600) / 60)
    local s = math.mod(seconds, 60)
    if h > 0 then
        return string.format("%dh %02dm", h, m)
    else
        return string.format("%dm %02ds", m, s)
    end
end

local function Print(msg)
    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage("|cffffcc00[XP]|r " .. tostring(msg))
    end
end

local function clamp(v, lo, hi)
    if v < lo then return lo end
    if v > hi then return hi end
    return v
end

-----------------------------------------------------------------------
-- UI construction
-----------------------------------------------------------------------
local frame, titleFS, bodyFS
local xpBar, restedBar, xpBarText
local resizeGrip

-- Vanilla default XP-bar colors
local COLOR_XP     = { r = 0.58, g = 0.0,  b = 0.55 } -- purple
local COLOR_RESTED = { r = 0.0,  g = 0.39, b = 0.88 } -- blue
local STATUSBAR_TEX= "Interface\\TargetingFrame\\UI-StatusBar"

-- Try to set a specific font; if it fails, keep the inherited template
-- font but apply the requested size via the current font path.
local function SafeSetFont(fs, path, size, flags)
    if not fs then return end
    if not fs:SetFont(path, size, flags or "") then
        -- SetFont returned false (font file missing) — keep current
        -- font path from the template, only change size/flags.
        local curPath = fs:GetFont()
        if curPath then
            fs:SetFont(curPath, size, flags or "")
        end
    end
end

local function ApplyFontSize()
    local sz = TurtleXPTrackerDB.frame.fontSize
    SafeSetFont(bodyFS,    "Fonts\\FRIZQT__.TTF", sz,     "")
    SafeSetFont(xpBarText, "Fonts\\FRIZQT__.TTF", sz - 1, "OUTLINE")
    SafeSetFont(titleFS,   "Fonts\\MORPHEUS.TTF", sz + 3, "")
    if titleFS then
        titleFS:SetTextColor(1, 0.82, 0)  -- WoW gold
    end
end

local function ApplyFrameSize()
    local db = TurtleXPTrackerDB.frame
    frame:SetWidth(db.width)
    frame:SetHeight(db.height)
    frame:SetScale(db.scale or 1.0)
end

local function CreateUI()
    frame = CreateFrame("Frame", "TurtleXPTrackerFrame", UIParent)

    -- Position & size
    local db = TurtleXPTrackerDB.frame
    frame:ClearAllPoints()
    frame:SetPoint(db.point, UIParent, db.relPoint, db.x, db.y)
    frame:SetWidth(db.width)
    frame:SetHeight(db.height)
    frame:SetScale(db.scale or 1.0)
    frame:SetFrameStrata("MEDIUM")

    -- Vanilla gold-bordered dialog look
    frame:SetBackdrop({
        bgFile   = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 32, edgeSize = 32,
        insets = { left = 11, right = 12, top = 12, bottom = 11 },
    })
    frame:SetBackdropColor(0, 0, 0, 0.85)

    -- Drag
    frame:SetMovable(true)
    frame:SetResizable(true)
    frame:SetMinResize(200, 120)
    frame:SetMaxResize(600, 400)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", function()
        if not TurtleXPTrackerDB.frame.locked then this:StartMoving() end
    end)
    frame:SetScript("OnDragStop", function()
        this:StopMovingOrSizing()
        local point, _, relPoint, x, y = this:GetPoint()
        TurtleXPTrackerDB.frame.point    = point
        TurtleXPTrackerDB.frame.relPoint = relPoint
        TurtleXPTrackerDB.frame.x        = x
        TurtleXPTrackerDB.frame.y        = y
    end)

    -- Scroll wheel adjusts font size
    frame:EnableMouseWheel(true)
    frame:SetScript("OnMouseWheel", function()
        local delta = arg1 or 0
        local d = TurtleXPTrackerDB.frame
        d.fontSize = clamp((d.fontSize or 12) + delta, 8, 24)
        ApplyFontSize()
    end)

    -- Title bar (decorative texture behind the title text)
    local titleBg = frame:CreateTexture(nil, "ARTWORK")
    titleBg:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Header")
    titleBg:SetWidth(256)
    titleBg:SetHeight(64)
    titleBg:SetPoint("TOP", frame, "TOP", 0, 12)

    titleFS = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    titleFS:SetPoint("TOP", frame, "TOP", 0, 0)
    titleFS:SetText("Turtle XP Tracker")

    -- Body text block
    bodyFS = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    bodyFS:SetPoint("TOPLEFT",  frame, "TOPLEFT",  18, -30)
    bodyFS:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -18, -30)
    bodyFS:SetJustifyH("LEFT")
    bodyFS:SetJustifyV("TOP")
    bodyFS:SetText("Gaining data...")

    -- XP progress bar (pinned to bottom)
    local barBG = CreateFrame("Frame", nil, frame)
    barBG:SetPoint("BOTTOMLEFT",  frame, "BOTTOMLEFT",  18, 14)
    barBG:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -18, 14)
    barBG:SetHeight(14)
    barBG:SetBackdrop({
        bgFile   = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 8, edgeSize = 8,
        insets = { left = 2, right = 2, top = 2, bottom = 2 },
    })
    barBG:SetBackdropColor(0, 0, 0, 0.8)

    -- Rested (drawn first, behind XP, so XP overlays it)
    restedBar = CreateFrame("StatusBar", nil, barBG)
    restedBar:SetPoint("TOPLEFT",     barBG, "TOPLEFT",      2,  -2)
    restedBar:SetPoint("BOTTOMRIGHT", barBG, "BOTTOMRIGHT", -2,   2)
    restedBar:SetStatusBarTexture(STATUSBAR_TEX)
    restedBar:SetStatusBarColor(COLOR_RESTED.r, COLOR_RESTED.g, COLOR_RESTED.b, 0.85)
    restedBar:SetMinMaxValues(0, 1)
    restedBar:SetValue(0)

    xpBar = CreateFrame("StatusBar", nil, barBG)
    xpBar:SetPoint("TOPLEFT",     barBG, "TOPLEFT",      2,  -2)
    xpBar:SetPoint("BOTTOMRIGHT", barBG, "BOTTOMRIGHT", -2,   2)
    xpBar:SetStatusBarTexture(STATUSBAR_TEX)
    xpBar:SetStatusBarColor(COLOR_XP.r, COLOR_XP.g, COLOR_XP.b, 1.0)
    xpBar:SetMinMaxValues(0, 1)
    xpBar:SetValue(0)
    xpBar:SetFrameLevel(restedBar:GetFrameLevel() + 1)

    -- Overlay frame sits ABOVE the status bars so the text is not
    -- hidden by the bar textures.
    local barOverlay = CreateFrame("Frame", nil, barBG)
    barOverlay:SetAllPoints(barBG)
    barOverlay:SetFrameLevel(xpBar:GetFrameLevel() + 2)

    xpBarText = barOverlay:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    xpBarText:SetPoint("CENTER", barOverlay, "CENTER", 0, 0)
    xpBarText:SetTextColor(1, 1, 1, 1)
    xpBarText:SetShadowColor(0, 0, 0, 1)
    xpBarText:SetShadowOffset(1, -1)

    -- Resize grip (bottom-right)
    resizeGrip = CreateFrame("Button", nil, frame)
    resizeGrip:SetWidth(16)
    resizeGrip:SetHeight(16)
    resizeGrip:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -6, 6)
    resizeGrip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    resizeGrip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    resizeGrip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    resizeGrip:SetScript("OnMouseDown", function()
        if not TurtleXPTrackerDB.frame.locked then
            frame:StartSizing("BOTTOMRIGHT")
        end
    end)
    resizeGrip:SetScript("OnMouseUp", function()
        frame:StopMovingOrSizing()
        TurtleXPTrackerDB.frame.width  = frame:GetWidth()
        TurtleXPTrackerDB.frame.height = frame:GetHeight()
    end)

    ApplyFontSize()

    if TurtleXPTrackerDB.frame.shown then
        frame:Show()
    else
        frame:Hide()
    end
end

-----------------------------------------------------------------------
-- Display update
-----------------------------------------------------------------------
local BODY_FMT =
    "XP/hr:       |cff00ff88%s|r\n" ..
    "Session:     %s XP  (%s)\n" ..
    "Level %d:   %s / %s  (%.1f%%)\n" ..
    "To level:    |cffffd100%s|r\n" ..
    "Kills:       %d    Avg/kill: %s\n" ..
    "Rested:      |cff99ccff%s|r  (%.0f%%)"

local function UpdateDisplay()
    if not frame or not frame:IsShown() then return end
    local db = TurtleXPTrackerDB

    local xp     = UnitXP("player")    or 0
    local xpMax  = UnitXPMax("player") or 1
    local level  = UnitLevel("player") or 1
    local rested = GetXPExhaustion()   or 0
    local pct    = (xp / xpMax) * 100
    local restedPct = (rested / xpMax) * 100

    local xpPerHour = 0
    if db.sessionSeconds > 0 then
        xpPerHour = (db.sessionXP / db.sessionSeconds) * 3600
    end

    local toLevel = "--"
    if xpPerHour > 0 then
        local xpNeeded = xpMax - xp
        toLevel = fmt_time((xpNeeded / xpPerHour) * 3600)
    end

    local avgPerKill = "--"
    if db.kills > 0 then
        avgPerKill = fmt_int(db.killXP / db.kills)
    end

    bodyFS:SetText(string.format(BODY_FMT,
        fmt_int(xpPerHour),
        fmt_int(db.sessionXP),
        fmt_time(db.sessionSeconds),
        level,
        fmt_int(xp),
        fmt_int(xpMax),
        pct,
        toLevel,
        db.kills,
        avgPerKill,
        fmt_int(rested),
        restedPct
    ))

    -- XP progress bar
    xpBar:SetMinMaxValues(0, xpMax)
    xpBar:SetValue(xp)

    -- Rested overlay extends from current XP to current XP + rested
    -- We fake the overlay by setting restedBar to xp+rested; since XP
    -- bar is drawn on top, only the rested portion past xp is visible.
    local restedEnd = xp + rested
    if restedEnd > xpMax then restedEnd = xpMax end
    restedBar:SetMinMaxValues(0, xpMax)
    restedBar:SetValue(restedEnd)

    xpBarText:SetText(string.format("%d / %d  (%.1f%%)", xp, xpMax, pct))
end

-----------------------------------------------------------------------
-- OnUpdate ticker
-----------------------------------------------------------------------
local tickAccum = 0
local uiAccum   = 0
local function OnUpdate(elapsed)
    elapsed = elapsed or arg1 or 0
    tickAccum = tickAccum + elapsed
    uiAccum   = uiAccum + elapsed

    if tickAccum >= 1.0 then
        TurtleXPTrackerDB.sessionSeconds =
            TurtleXPTrackerDB.sessionSeconds + tickAccum
        tickAccum = 0
    end
    if uiAccum >= 0.5 then
        UpdateDisplay()
        uiAccum = 0
    end
end

-----------------------------------------------------------------------
-- XP tracking
-----------------------------------------------------------------------
local function RecordXPGain(gained)
    if gained <= 0 then return end
    TurtleXPTrackerDB.sessionXP = TurtleXPTrackerDB.sessionXP + gained
end

local function HandleXPUpdate()
    local db    = TurtleXPTrackerDB
    local xp    = UnitXP("player")    or 0
    local level = UnitLevel("player") or 1

    if db.lastXP == nil or db.lastLevel == nil then
        db.lastXP    = xp
        db.lastLevel = level
        return
    end

    if level > db.lastLevel then
        local oldMax = UnitXPMax("player")
        local gained = (oldMax - db.lastXP) + xp
        if gained < 0 then gained = xp end
        RecordXPGain(gained)
    else
        local gained = xp - db.lastXP
        if gained > 0 then
            RecordXPGain(gained)
        end
    end

    db.lastXP    = xp
    db.lastLevel = level
end

-----------------------------------------------------------------------
-- Kill XP from combat log
-----------------------------------------------------------------------
local function HandleCombatXP(msg)
    if not msg then return end
    local _, _, num = string.find(msg, "(%d+) experience")
    local n = num and tonumber(num) or nil
    if n and n > 0 then
        TurtleXPTrackerDB.kills  = TurtleXPTrackerDB.kills + 1
        TurtleXPTrackerDB.killXP = TurtleXPTrackerDB.killXP + n
    end
end

-----------------------------------------------------------------------
-- Slash commands
-----------------------------------------------------------------------
local function SlashHandler(msg)
    msg = string.lower(msg or "")

    -- Split "cmd arg" into cmd, arg
    local _, _, cmd, arg = string.find(msg, "^(%S*)%s*(.-)%s*$")
    cmd = cmd or ""

    if cmd == "reset" then
        if arg == "pos" then
            TurtleXPTrackerDB.frame.point    = "CENTER"
            TurtleXPTrackerDB.frame.relPoint = "CENTER"
            TurtleXPTrackerDB.frame.x        = 0
            TurtleXPTrackerDB.frame.y        = 200
            frame:ClearAllPoints()
            frame:SetPoint("CENTER", UIParent, "CENTER", 0, 200)
            Print("Frame position reset.")
        elseif arg == "all" then
            TurtleXPTrackerDB = nil
            InitDB()
            frame:ClearAllPoints()
            local d = TurtleXPTrackerDB.frame
            frame:SetPoint(d.point, UIParent, d.relPoint, d.x, d.y)
            ApplyFrameSize()
            ApplyFontSize()
            TurtleXPTrackerDB.lastXP    = UnitXP("player")
            TurtleXPTrackerDB.lastLevel = UnitLevel("player")
            Print("All settings and session reset.")
        else
            TurtleXPTrackerDB.sessionXP      = 0
            TurtleXPTrackerDB.sessionSeconds = 0
            TurtleXPTrackerDB.kills          = 0
            TurtleXPTrackerDB.killXP         = 0
            TurtleXPTrackerDB.lastXP         = UnitXP("player")
            TurtleXPTrackerDB.lastLevel      = UnitLevel("player")
            Print("Session reset.")
        end
        UpdateDisplay()

    elseif cmd == "show" then
        TurtleXPTrackerDB.frame.shown = true
        frame:Show()
        UpdateDisplay()

    elseif cmd == "hide" then
        TurtleXPTrackerDB.frame.shown = false
        frame:Hide()

    elseif cmd == "toggle" or cmd == "" then
        if frame:IsShown() then
            TurtleXPTrackerDB.frame.shown = false
            frame:Hide()
        else
            TurtleXPTrackerDB.frame.shown = true
            frame:Show()
            UpdateDisplay()
        end

    elseif cmd == "lock" then
        TurtleXPTrackerDB.frame.locked = true
        Print("Frame locked. /xp unlock to move/resize again.")

    elseif cmd == "unlock" then
        TurtleXPTrackerDB.frame.locked = false
        Print("Frame unlocked.")

    elseif cmd == "font" then
        local n = tonumber(arg)
        if n and n >= 6 and n <= 32 then
            TurtleXPTrackerDB.frame.fontSize = n
            ApplyFontSize()
            Print("Font size: " .. n)
        else
            Print("Usage: /xp font <6-32>   (current: "
                .. TurtleXPTrackerDB.frame.fontSize .. ")")
        end

    elseif cmd == "scale" then
        local n = tonumber(arg)
        if n and n >= 0.5 and n <= 2.0 then
            TurtleXPTrackerDB.frame.scale = n
            frame:SetScale(n)
            Print("Scale: " .. n)
        else
            Print("Usage: /xp scale <0.5-2.0>   (current: "
                .. TurtleXPTrackerDB.frame.scale .. ")")
        end

    elseif cmd == "size" then
        -- /xp size WxH, e.g. /xp size 320x180
        local _, _, w, h = string.find(arg, "(%d+)x(%d+)")
        w, h = tonumber(w), tonumber(h)
        if w and h then
            w = clamp(w, 200, 600)
            h = clamp(h, 120, 400)
            TurtleXPTrackerDB.frame.width  = w
            TurtleXPTrackerDB.frame.height = h
            ApplyFrameSize()
            Print("Size: " .. w .. "x" .. h)
        else
            Print("Usage: /xp size <width>x<height>   e.g. /xp size 320x180")
            Print("   current: " .. math.floor(frame:GetWidth()) .. "x"
                .. math.floor(frame:GetHeight()))
        end

    elseif cmd == "help" or cmd == "?" then
        Print("--- Turtle XP Tracker ---")
        Print("/xp                 Toggle window")
        Print("/xp reset           Reset session XP, time, kills")
        Print("/xp reset pos       Reset window position")
        Print("/xp reset all       Reset everything to defaults")
        Print("/xp show | hide     Show / hide window")
        Print("/xp lock | unlock   Prevent / allow drag & resize")
        Print("/xp font <6-32>     Set text size (or scroll wheel on frame)")
        Print("/xp scale <0.5-2>   Set overall UI scale")
        Print("/xp size WxH        Set window size (e.g. 320x180)")

    else
        Print("Unknown command '" .. cmd .. "'. Type /xp help.")
    end
end

SLASH_TURTLEXP1 = "/xp"
SLASH_TURTLEXP2 = "/turtlexp"
SlashCmdList["TURTLEXP"] = SlashHandler

-----------------------------------------------------------------------
-- Event wiring
-----------------------------------------------------------------------
local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("PLAYER_XP_UPDATE")
eventFrame:RegisterEvent("PLAYER_LEVEL_UP")
eventFrame:RegisterEvent("UPDATE_EXHAUSTION")
eventFrame:RegisterEvent("CHAT_MSG_COMBAT_XP_GAIN")

eventFrame:SetScript("OnEvent", function()
    local ev = event
    if ev == "ADDON_LOADED" then
        if arg1 == ADDON_NAME then InitDB() end
    elseif ev == "PLAYER_LOGIN" then
        InitDB()
        CreateUI()
        TurtleXPTrackerDB.lastXP    = UnitXP("player")
        TurtleXPTrackerDB.lastLevel = UnitLevel("player")
        eventFrame:SetScript("OnUpdate", OnUpdate)
        UpdateDisplay()
        Print("Loaded v1.1. /xp help for options.")
    elseif ev == "PLAYER_XP_UPDATE" or ev == "PLAYER_LEVEL_UP" then
        HandleXPUpdate()
        UpdateDisplay()
    elseif ev == "UPDATE_EXHAUSTION" then
        UpdateDisplay()
    elseif ev == "CHAT_MSG_COMBAT_XP_GAIN" then
        HandleCombatXP(arg1)
    end
end)
